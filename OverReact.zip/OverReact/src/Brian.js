var React = require('react');


var Brian = React.createClass({
  render: function () {
    return (
      <div id='Brian'>
        Brian
        
      </div>
    )
  }
});

module.exports = Brian;


