var React = require('react');


var Rico = React.createClass({
  render: function () {
    return (
      <div id='Rico'>
        Rico
        
      </div>
    )
  }
});

module.exports = Rico;


