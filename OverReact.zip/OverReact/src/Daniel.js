var React = require('react');


var Daniel = React.createClass({
  render: function () {
    return (
      <div id='Daniel'>
        Daniel
        
      </div>
    )
  }
});

module.exports = Daniel;


