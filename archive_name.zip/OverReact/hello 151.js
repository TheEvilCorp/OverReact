var React = require('react');
var $ = require('jquery');


var hello 151 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello 151</div>
      </div>
    )
  }
});

module.exports = hello 151;


