var React = require('react');
var $ = require('jquery');


var hello186 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello186</div>
      </div>
    )
  }
});

module.exports = hello186;


