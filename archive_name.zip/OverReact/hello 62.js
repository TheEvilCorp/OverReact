var React = require('react');
var $ = require('jquery');


var hello 62 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello 62</div>
      </div>
    )
  }
});

module.exports = hello 62;


