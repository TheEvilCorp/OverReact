var React = require('react');
var $ = require('jquery');


var hello 147 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello 147</div>
      </div>
    )
  }
});

module.exports = hello 147;


