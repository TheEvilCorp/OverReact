var React = require('react');
var $ = require('jquery');


var hello19 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello19</div>
      </div>
    )
  }
});

module.exports = hello19;


