var React = require('react');
var $ = require('jquery');


var hello6 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello6</div>
      </div>
    )
  }
});

module.exports = hello6;


