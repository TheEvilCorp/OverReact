var React = require('react');
var $ = require('jquery');


var hello 193 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello 193</div>
      </div>
    )
  }
});

module.exports = hello 193;


