var React = require('react');
var $ = require('jquery');


var hello112 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello112</div>
      </div>
    )
  }
});

module.exports = hello112;


