var React = require('react');
var $ = require('jquery');


var hello 74 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello 74</div>
      </div>
    )
  }
});

module.exports = hello 74;


