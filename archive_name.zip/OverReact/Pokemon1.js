var React = require('react');
var $ = require('jquery');


var Pokemon1 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>Pokemon1</div>
      </div>
    )
  }
});

module.exports = Pokemon1;


