var React = require('react');
var $ = require('jquery');


var hello141 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello141</div>
      </div>
    )
  }
});

module.exports = hello141;


