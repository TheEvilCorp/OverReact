var React = require('react');
var $ = require('jquery');


var hello70 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello70</div>
      </div>
    )
  }
});

module.exports = hello70;


