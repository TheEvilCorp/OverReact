var React = require('react');
var $ = require('jquery');


var hello 136 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello 136</div>
      </div>
    )
  }
});

module.exports = hello 136;


