var React = require('react');
var $ = require('jquery');


var hello0 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello0</div>
      </div>
    )
  }
});

module.exports = hello0;


