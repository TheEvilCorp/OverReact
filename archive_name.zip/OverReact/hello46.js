var React = require('react');
var $ = require('jquery');


var hello46 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello46</div>
      </div>
    )
  }
});

module.exports = hello46;


