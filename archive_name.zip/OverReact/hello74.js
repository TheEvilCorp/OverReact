var React = require('react');
var $ = require('jquery');


var hello74 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello74</div>
      </div>
    )
  }
});

module.exports = hello74;


