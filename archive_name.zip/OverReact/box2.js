var React = require('react');
var $ = require('jquery');


var box2 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>box2</div>
      </div>
    )
  }
});

module.exports = box2;


