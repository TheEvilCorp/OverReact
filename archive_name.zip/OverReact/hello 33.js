var React = require('react');
var $ = require('jquery');


var hello 33 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello 33</div>
      </div>
    )
  }
});

module.exports = hello 33;


