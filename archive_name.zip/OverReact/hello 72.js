var React = require('react');
var $ = require('jquery');


var hello 72 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello 72</div>
      </div>
    )
  }
});

module.exports = hello 72;


