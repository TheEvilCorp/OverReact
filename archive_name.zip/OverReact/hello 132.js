var React = require('react');
var $ = require('jquery');


var hello 132 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello 132</div>
      </div>
    )
  }
});

module.exports = hello 132;


