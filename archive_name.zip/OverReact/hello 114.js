var React = require('react');
var $ = require('jquery');


var hello 114 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello 114</div>
      </div>
    )
  }
});

module.exports = hello 114;


