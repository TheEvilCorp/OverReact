var React = require('react');
var $ = require('jquery');


var hello 161 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello 161</div>
      </div>
    )
  }
});

module.exports = hello 161;


