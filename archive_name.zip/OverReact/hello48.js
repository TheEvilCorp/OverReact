var React = require('react');
var $ = require('jquery');


var hello48 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello48</div>
      </div>
    )
  }
});

module.exports = hello48;


