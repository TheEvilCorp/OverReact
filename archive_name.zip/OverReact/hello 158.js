var React = require('react');
var $ = require('jquery');


var hello 158 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello 158</div>
      </div>
    )
  }
});

module.exports = hello 158;


