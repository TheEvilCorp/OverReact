var React = require('react');
var $ = require('jquery');


var hello 81 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello 81</div>
      </div>
    )
  }
});

module.exports = hello 81;


