var React = require('react');
var $ = require('jquery');


var hello 194 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello 194</div>
      </div>
    )
  }
});

module.exports = hello 194;


