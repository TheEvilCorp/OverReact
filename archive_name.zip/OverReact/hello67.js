var React = require('react');
var $ = require('jquery');


var hello67 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello67</div>
      </div>
    )
  }
});

module.exports = hello67;


