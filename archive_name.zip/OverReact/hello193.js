var React = require('react');
var $ = require('jquery');


var hello193 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello193</div>
      </div>
    )
  }
});

module.exports = hello193;


