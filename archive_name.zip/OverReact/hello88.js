var React = require('react');
var $ = require('jquery');


var hello88 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello88</div>
      </div>
    )
  }
});

module.exports = hello88;


