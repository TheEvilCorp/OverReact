var React = require('react');
var $ = require('jquery');


var hello 18 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello 18</div>
      </div>
    )
  }
});

module.exports = hello 18;


