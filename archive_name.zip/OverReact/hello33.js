var React = require('react');
var $ = require('jquery');


var hello33 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello33</div>
      </div>
    )
  }
});

module.exports = hello33;


