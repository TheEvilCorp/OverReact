var React = require('react');
var $ = require('jquery');


var hello29 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello29</div>
      </div>
    )
  }
});

module.exports = hello29;


