var React = require('react');
var $ = require('jquery');


var hello188 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello188</div>
      </div>
    )
  }
});

module.exports = hello188;


