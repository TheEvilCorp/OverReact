var React = require('react');
var $ = require('jquery');


var hello 124 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello 124</div>
      </div>
    )
  }
});

module.exports = hello 124;


