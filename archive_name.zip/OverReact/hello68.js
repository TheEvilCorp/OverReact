var React = require('react');
var $ = require('jquery');


var hello68 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello68</div>
      </div>
    )
  }
});

module.exports = hello68;


