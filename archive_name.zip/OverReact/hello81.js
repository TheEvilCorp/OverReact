var React = require('react');
var $ = require('jquery');


var hello81 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello81</div>
      </div>
    )
  }
});

module.exports = hello81;


