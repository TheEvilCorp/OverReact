var React = require('react');
var $ = require('jquery');


var hello107 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello107</div>
      </div>
    )
  }
});

module.exports = hello107;


