var React = require('react');
var $ = require('jquery');


var hello197 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello197</div>
      </div>
    )
  }
});

module.exports = hello197;


