var React = require('react');
var $ = require('jquery');


var hello56 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello56</div>
      </div>
    )
  }
});

module.exports = hello56;


