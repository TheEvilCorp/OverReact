var React = require('react');
var $ = require('jquery');


var hello35 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello35</div>
      </div>
    )
  }
});

module.exports = hello35;


