var React = require('react');
var $ = require('jquery');


var hello154 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello154</div>
      </div>
    )
  }
});

module.exports = hello154;


