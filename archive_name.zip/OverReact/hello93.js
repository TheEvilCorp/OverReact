var React = require('react');
var $ = require('jquery');


var hello93 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello93</div>
      </div>
    )
  }
});

module.exports = hello93;


