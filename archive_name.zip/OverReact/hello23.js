var React = require('react');
var $ = require('jquery');


var hello23 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello23</div>
      </div>
    )
  }
});

module.exports = hello23;


