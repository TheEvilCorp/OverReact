var React = require('react');
var $ = require('jquery');


var hello 82 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello 82</div>
      </div>
    )
  }
});

module.exports = hello 82;


