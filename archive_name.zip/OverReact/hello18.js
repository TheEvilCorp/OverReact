var React = require('react');
var $ = require('jquery');


var hello18 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello18</div>
      </div>
    )
  }
});

module.exports = hello18;


