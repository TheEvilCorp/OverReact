var React = require('react');
var $ = require('jquery');


var hello162 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello162</div>
      </div>
    )
  }
});

module.exports = hello162;


