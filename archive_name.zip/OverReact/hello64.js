var React = require('react');
var $ = require('jquery');


var hello64 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello64</div>
      </div>
    )
  }
});

module.exports = hello64;


