var React = require('react');
var $ = require('jquery');


var hello49 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello49</div>
      </div>
    )
  }
});

module.exports = hello49;


