var React = require('react');
var $ = require('jquery');


var hello 173 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello 173</div>
      </div>
    )
  }
});

module.exports = hello 173;


