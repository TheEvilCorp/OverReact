var React = require('react');
var $ = require('jquery');


var hello96 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello96</div>
      </div>
    )
  }
});

module.exports = hello96;


