var React = require('react');
var $ = require('jquery');


var hello15 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello15</div>
      </div>
    )
  }
});

module.exports = hello15;


