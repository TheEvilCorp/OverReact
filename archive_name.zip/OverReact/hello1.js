var React = require('react');
var $ = require('jquery');


var hello1 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello1</div>
      </div>
    )
  }
});

module.exports = hello1;


