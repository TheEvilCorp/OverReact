var React = require('react');
var $ = require('jquery');


var hello 85 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello 85</div>
      </div>
    )
  }
});

module.exports = hello 85;


