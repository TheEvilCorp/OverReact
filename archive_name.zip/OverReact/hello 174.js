var React = require('react');
var $ = require('jquery');


var hello 174 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello 174</div>
      </div>
    )
  }
});

module.exports = hello 174;


