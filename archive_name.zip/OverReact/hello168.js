var React = require('react');
var $ = require('jquery');


var hello168 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello168</div>
      </div>
    )
  }
});

module.exports = hello168;


