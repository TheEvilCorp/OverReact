var React = require('react');
var $ = require('jquery');


var hello174 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello174</div>
      </div>
    )
  }
});

module.exports = hello174;


