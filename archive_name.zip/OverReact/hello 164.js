var React = require('react');
var $ = require('jquery');


var hello 164 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello 164</div>
      </div>
    )
  }
});

module.exports = hello 164;


