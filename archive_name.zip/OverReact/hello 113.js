var React = require('react');
var $ = require('jquery');


var hello 113 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello 113</div>
      </div>
    )
  }
});

module.exports = hello 113;


