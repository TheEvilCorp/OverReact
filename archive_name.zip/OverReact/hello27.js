var React = require('react');
var $ = require('jquery');


var hello27 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello27</div>
      </div>
    )
  }
});

module.exports = hello27;


