var React = require('react');
var $ = require('jquery');


var hello151 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello151</div>
      </div>
    )
  }
});

module.exports = hello151;


