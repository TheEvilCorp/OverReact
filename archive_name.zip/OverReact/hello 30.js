var React = require('react');
var $ = require('jquery');


var hello 30 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello 30</div>
      </div>
    )
  }
});

module.exports = hello 30;


