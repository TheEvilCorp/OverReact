var React = require('react');
var $ = require('jquery');


var hello8 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello8</div>
      </div>
    )
  }
});

module.exports = hello8;


