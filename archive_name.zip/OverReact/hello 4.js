var React = require('react');
var $ = require('jquery');


var hello 4 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello 4</div>
      </div>
    )
  }
});

module.exports = hello 4;


