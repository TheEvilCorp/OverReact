var React = require('react');
var $ = require('jquery');


var hello45 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello45</div>
      </div>
    )
  }
});

module.exports = hello45;


