var React = require('react');
var $ = require('jquery');


var hello 195 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello 195</div>
      </div>
    )
  }
});

module.exports = hello 195;


