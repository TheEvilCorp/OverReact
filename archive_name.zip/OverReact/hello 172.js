var React = require('react');
var $ = require('jquery');


var hello 172 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello 172</div>
      </div>
    )
  }
});

module.exports = hello 172;


