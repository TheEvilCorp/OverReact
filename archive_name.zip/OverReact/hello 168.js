var React = require('react');
var $ = require('jquery');


var hello 168 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello 168</div>
      </div>
    )
  }
});

module.exports = hello 168;


