var React = require('react');
var $ = require('jquery');


var hello120 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello120</div>
      </div>
    )
  }
});

module.exports = hello120;


