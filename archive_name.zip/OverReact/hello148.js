var React = require('react');
var $ = require('jquery');


var hello148 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello148</div>
      </div>
    )
  }
});

module.exports = hello148;


