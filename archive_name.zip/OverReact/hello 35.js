var React = require('react');
var $ = require('jquery');


var hello 35 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello 35</div>
      </div>
    )
  }
});

module.exports = hello 35;


