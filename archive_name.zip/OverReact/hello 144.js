var React = require('react');
var $ = require('jquery');


var hello 144 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello 144</div>
      </div>
    )
  }
});

module.exports = hello 144;


