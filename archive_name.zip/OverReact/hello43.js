var React = require('react');
var $ = require('jquery');


var hello43 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello43</div>
      </div>
    )
  }
});

module.exports = hello43;


