var React = require('react');
var $ = require('jquery');


var hello 67 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello 67</div>
      </div>
    )
  }
});

module.exports = hello 67;


