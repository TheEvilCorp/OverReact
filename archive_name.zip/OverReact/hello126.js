var React = require('react');
var $ = require('jquery');


var hello126 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello126</div>
      </div>
    )
  }
});

module.exports = hello126;


