var React = require('react');
var $ = require('jquery');


var hello166 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello166</div>
      </div>
    )
  }
});

module.exports = hello166;


