var React = require('react');
var $ = require('jquery');


var hello 17 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello 17</div>
      </div>
    )
  }
});

module.exports = hello 17;


