var React = require('react');
var $ = require('jquery');


var hello72 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello72</div>
      </div>
    )
  }
});

module.exports = hello72;


