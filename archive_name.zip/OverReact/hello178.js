var React = require('react');
var $ = require('jquery');


var hello178 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello178</div>
      </div>
    )
  }
});

module.exports = hello178;


