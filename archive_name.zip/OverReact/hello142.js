var React = require('react');
var $ = require('jquery');


var hello142 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello142</div>
      </div>
    )
  }
});

module.exports = hello142;


