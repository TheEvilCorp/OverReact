var React = require('react');
var $ = require('jquery');


var hello102 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello102</div>
      </div>
    )
  }
});

module.exports = hello102;


