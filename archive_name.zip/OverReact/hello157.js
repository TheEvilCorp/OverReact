var React = require('react');
var $ = require('jquery');


var hello157 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello157</div>
      </div>
    )
  }
});

module.exports = hello157;


