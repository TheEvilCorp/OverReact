var React = require('react');
var $ = require('jquery');


var hello60 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello60</div>
      </div>
    )
  }
});

module.exports = hello60;


