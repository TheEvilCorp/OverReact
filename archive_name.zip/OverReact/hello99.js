var React = require('react');
var $ = require('jquery');


var hello99 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello99</div>
      </div>
    )
  }
});

module.exports = hello99;


