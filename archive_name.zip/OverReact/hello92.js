var React = require('react');
var $ = require('jquery');


var hello92 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello92</div>
      </div>
    )
  }
});

module.exports = hello92;


