var React = require('react');
var $ = require('jquery');


var hello152 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello152</div>
      </div>
    )
  }
});

module.exports = hello152;


