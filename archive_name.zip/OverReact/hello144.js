var React = require('react');
var $ = require('jquery');


var hello144 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello144</div>
      </div>
    )
  }
});

module.exports = hello144;


