var React = require('react');
var $ = require('jquery');


var hello36 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello36</div>
      </div>
    )
  }
});

module.exports = hello36;


