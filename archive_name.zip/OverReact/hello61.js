var React = require('react');
var $ = require('jquery');


var hello61 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello61</div>
      </div>
    )
  }
});

module.exports = hello61;


