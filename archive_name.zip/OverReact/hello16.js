var React = require('react');
var $ = require('jquery');


var hello16 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello16</div>
      </div>
    )
  }
});

module.exports = hello16;


