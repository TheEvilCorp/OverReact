var React = require('react');
var $ = require('jquery');


var hello4 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello4</div>
      </div>
    )
  }
});

module.exports = hello4;


