var React = require('react');
var $ = require('jquery');


var hello145 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello145</div>
      </div>
    )
  }
});

module.exports = hello145;


