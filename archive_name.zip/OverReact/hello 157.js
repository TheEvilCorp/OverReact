var React = require('react');
var $ = require('jquery');


var hello 157 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello 157</div>
      </div>
    )
  }
});

module.exports = hello 157;


