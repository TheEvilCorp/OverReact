var React = require('react');
var $ = require('jquery');


var hello128 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello128</div>
      </div>
    )
  }
});

module.exports = hello128;


