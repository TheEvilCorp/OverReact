var React = require('react');
var $ = require('jquery');


var hello 86 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello 86</div>
      </div>
    )
  }
});

module.exports = hello 86;


