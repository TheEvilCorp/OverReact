var React = require('react');
var $ = require('jquery');


var hello21 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello21</div>
      </div>
    )
  }
});

module.exports = hello21;


