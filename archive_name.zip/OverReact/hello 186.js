var React = require('react');
var $ = require('jquery');


var hello 186 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello 186</div>
      </div>
    )
  }
});

module.exports = hello 186;


