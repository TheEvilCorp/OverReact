var React = require('react');
var $ = require('jquery');


var hello 189 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello 189</div>
      </div>
    )
  }
});

module.exports = hello 189;


