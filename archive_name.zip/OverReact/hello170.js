var React = require('react');
var $ = require('jquery');


var hello170 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello170</div>
      </div>
    )
  }
});

module.exports = hello170;


