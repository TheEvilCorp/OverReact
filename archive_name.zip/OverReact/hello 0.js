var React = require('react');
var $ = require('jquery');


var hello 0 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello 0</div>
      </div>
    )
  }
});

module.exports = hello 0;


