var React = require('react');
var $ = require('jquery');


var Pokemon3 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>Pokemon3</div>
      </div>
    )
  }
});

module.exports = Pokemon3;


