var React = require('react');
var $ = require('jquery');


var hello2 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello2</div>
      </div>
    )
  }
});

module.exports = hello2;


