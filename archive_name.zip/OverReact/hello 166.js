var React = require('react');
var $ = require('jquery');


var hello 166 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello 166</div>
      </div>
    )
  }
});

module.exports = hello 166;


