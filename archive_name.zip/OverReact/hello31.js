var React = require('react');
var $ = require('jquery');


var hello31 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello31</div>
      </div>
    )
  }
});

module.exports = hello31;


