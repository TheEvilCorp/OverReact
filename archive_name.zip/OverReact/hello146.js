var React = require('react');
var $ = require('jquery');


var hello146 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello146</div>
      </div>
    )
  }
});

module.exports = hello146;


