var React = require('react');
var $ = require('jquery');


var hello143 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello143</div>
      </div>
    )
  }
});

module.exports = hello143;


