var React = require('react');
var $ = require('jquery');


var a = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>a</div>
      </div>
    )
  }
});

module.exports = a;


