var React = require('react');
var $ = require('jquery');


var hello 15 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello 15</div>
      </div>
    )
  }
});

module.exports = hello 15;


