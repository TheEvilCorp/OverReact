var React = require('react');
var $ = require('jquery');


var hello85 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello85</div>
      </div>
    )
  }
});

module.exports = hello85;


