var React = require('react');
var $ = require('jquery');


var hello62 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello62</div>
      </div>
    )
  }
});

module.exports = hello62;


