var React = require('react');
var $ = require('jquery');


var hello66 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello66</div>
      </div>
    )
  }
});

module.exports = hello66;


