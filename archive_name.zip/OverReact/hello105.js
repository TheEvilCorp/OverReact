var React = require('react');
var $ = require('jquery');


var hello105 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello105</div>
      </div>
    )
  }
});

module.exports = hello105;


