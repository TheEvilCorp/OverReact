var React = require('react');
var $ = require('jquery');


var hello 53 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello 53</div>
      </div>
    )
  }
});

module.exports = hello 53;


