var React = require('react');
var $ = require('jquery');


var hello194 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello194</div>
      </div>
    )
  }
});

module.exports = hello194;


