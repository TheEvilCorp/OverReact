var React = require('react');
var $ = require('jquery');


var hello 148 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello 148</div>
      </div>
    )
  }
});

module.exports = hello 148;


