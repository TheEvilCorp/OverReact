var React = require('react');
var $ = require('jquery');


var box3 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>box3</div>
      </div>
    )
  }
});

module.exports = box3;


