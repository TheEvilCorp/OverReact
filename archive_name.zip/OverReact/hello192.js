var React = require('react');
var $ = require('jquery');


var hello192 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello192</div>
      </div>
    )
  }
});

module.exports = hello192;


