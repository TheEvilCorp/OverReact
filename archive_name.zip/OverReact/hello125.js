var React = require('react');
var $ = require('jquery');


var hello125 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello125</div>
      </div>
    )
  }
});

module.exports = hello125;


