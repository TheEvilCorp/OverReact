var React = require('react');
var $ = require('jquery');


var PokeItem = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>PokeItem</div>
      </div>
    )
  }
});

module.exports = PokeItem;


