var React = require('react');
var $ = require('jquery');


var hello 9 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello 9</div>
      </div>
    )
  }
});

module.exports = hello 9;


