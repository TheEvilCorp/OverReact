var React = require('react');
var $ = require('jquery');


var hello 128 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello 128</div>
      </div>
    )
  }
});

module.exports = hello 128;


