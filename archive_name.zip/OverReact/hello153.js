var React = require('react');
var $ = require('jquery');


var hello153 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello153</div>
      </div>
    )
  }
});

module.exports = hello153;


