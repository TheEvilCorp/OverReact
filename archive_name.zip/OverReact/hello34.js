var React = require('react');
var $ = require('jquery');


var hello34 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello34</div>
      </div>
    )
  }
});

module.exports = hello34;


