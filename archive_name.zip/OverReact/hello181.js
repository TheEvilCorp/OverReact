var React = require('react');
var $ = require('jquery');


var hello181 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello181</div>
      </div>
    )
  }
});

module.exports = hello181;


