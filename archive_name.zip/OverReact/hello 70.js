var React = require('react');
var $ = require('jquery');


var hello 70 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello 70</div>
      </div>
    )
  }
});

module.exports = hello 70;


