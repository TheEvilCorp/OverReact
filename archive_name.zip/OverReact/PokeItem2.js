var React = require('react');
var $ = require('jquery');


var PokeItem2 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>PokeItem2</div>
      </div>
    )
  }
});

module.exports = PokeItem2;


