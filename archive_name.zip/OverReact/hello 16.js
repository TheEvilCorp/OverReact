var React = require('react');
var $ = require('jquery');


var hello 16 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello 16</div>
      </div>
    )
  }
});

module.exports = hello 16;


