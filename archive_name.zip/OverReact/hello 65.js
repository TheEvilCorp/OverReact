var React = require('react');
var $ = require('jquery');


var hello 65 = React.createClass({
  getInitialState: function() {
    return {};
  },
  render: function () {
    return (
      <div>
        <div>hello 65</div>
      </div>
    )
  }
});

module.exports = hello 65;


